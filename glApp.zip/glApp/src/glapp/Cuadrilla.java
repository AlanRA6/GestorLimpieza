/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package glapp;

/**
 *
 * @author edw09
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import conexion.DatabaseConnection;
import javax.swing.JOptionPane;

public class Cuadrilla {
    private int cuadrilla_id;
    private String nombre;
    private String ubicacion;
    private int jefeCuadrilla_id; // ID del jefe de cuadrilla
    private List<Personal> miembros = new ArrayList<>();

    // Constructor
    public Cuadrilla(int cuadrilla_id, String nombre, String ubicacion, int jefeCuadrilla_id) {
        this.cuadrilla_id = cuadrilla_id;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.jefeCuadrilla_id = jefeCuadrilla_id;
    }

    // Métodos CRUD de Cuadrilla en la base de datos
    public void guardar() {
        String sql = "INSERT INTO cuadrilla (cuadrilla_id, nombre, ubicacion, jefeCuadrilla_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, this.cuadrilla_id);
            pstmt.setString(2, this.nombre);
            pstmt.setString(3, this.ubicacion);
            pstmt.setInt(4, this.jefeCuadrilla_id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Cuadrilla guardada exitosamente.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al guardar la cuadrilla: " + e.getMessage());
        }
    }

    public static Cuadrilla obtenerPorId(int cuadrilla_id) {
        String sql = "SELECT * FROM cuadrilla WHERE cuadrilla_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cuadrilla_id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Cuadrilla(
                        rs.getInt("cuadrilla_id"),
                        rs.getString("nombre"),
                        rs.getString("ubicacion"),
                        rs.getInt("jefeCuadrilla_id")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la cuadrilla: " + e.getMessage());
        }
        return null;
    }

    public void actualizar() {
    String sql = "UPDATE cuadrilla SET nombre = ?, ubicacion = ?, jefeCuadrilla_id = ? WHERE cuadrilla_id = ?";
    try (Connection conn = DatabaseConnection.getInstance().getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, this.nombre);
        pstmt.setString(2, this.ubicacion);
        
        // Asigna NULL si el ID es 0
        if (this.jefeCuadrilla_id == 0) {
            pstmt.setNull(3, java.sql.Types.INTEGER);
        } else {
            pstmt.setInt(3, this.jefeCuadrilla_id);
        }
        
        pstmt.setInt(4, this.cuadrilla_id);
        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(null,"Cuadrilla actualizada exitosamente.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null,"Error al actualizar la cuadrillas.");;
    }
}


    public void eliminar() {
    // Desasociar miembros de la cuadrilla
    String desasociarMiembrosSQL = "UPDATE personal SET cuadrilla_id = NULL WHERE cuadrilla_id = ?";
    // Desasociar actividades de limpieza de la cuadrilla
    String desasociarActividadesSQL = "UPDATE actividadlimpieza SET cuadrilla_id = NULL WHERE cuadrilla_id = ?";
    // Eliminar la cuadrilla
    String eliminarCuadrillaSQL = "DELETE FROM cuadrilla WHERE cuadrilla_id = ?";

    try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
        conn.setAutoCommit(false);  // Iniciar transacción

        try (PreparedStatement pstmtDesasociarMiembros = conn.prepareStatement(desasociarMiembrosSQL);
             PreparedStatement pstmtDesasociarActividades = conn.prepareStatement(desasociarActividadesSQL);
             PreparedStatement pstmtEliminar = conn.prepareStatement(eliminarCuadrillaSQL)) {

            // Actualizar miembros para que su cuadrilla_id sea NULL
            pstmtDesasociarMiembros.setInt(1, this.cuadrilla_id);
            pstmtDesasociarMiembros.executeUpdate();

            // Actualizar actividades de limpieza para que su cuadrilla_id sea NULL
            pstmtDesasociarActividades.setInt(1, this.cuadrilla_id);
            pstmtDesasociarActividades.executeUpdate();

            // Eliminar la cuadrilla
            pstmtEliminar.setInt(1, this.cuadrilla_id);
            pstmtEliminar.executeUpdate();

            conn.commit();  // Confirmar transacción si ambas operaciones fueron exitosas
            System.out.println("Cuadrilla eliminada exitosamente.");

        } catch (SQLException e) {
            conn.rollback();  // Revertir cambios en caso de error
            System.out.println("Error al eliminar la cuadrilla: " + e.getMessage());
        }
    } catch (SQLException e) {
        System.out.println("Error al conectar a la base de datos: " + e.getMessage());
    }
}



    // Métodos de manipulación de miembros
// Agregar un miembro a la cuadrilla en la base de datos
public void addMiembro(Personal miembro) {
    String sql = "UPDATE personal SET cuadrilla_id = ? WHERE personal_id = ?";
    try (Connection conn = DatabaseConnection.getInstance().getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, this.cuadrilla_id); // Asignar esta cuadrilla al miembro
        pstmt.setInt(2, miembro.getPersonal_id()); // ID del miembro a actualizar
        pstmt.executeUpdate();
        
        miembros.add(miembro); // Agregar a la lista en memoria
        JOptionPane.showMessageDialog(null, "Miembro " + miembro.getNombre() + " agregado a la cuadrilla " + this.nombre);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al agregar miembro: " + e.getMessage());
    }
}

// Remover un miembro de la cuadrilla en la base de datos
public void removeMiembro(Personal miembro) {
    String sql = "UPDATE personal SET cuadrilla_id = NULL WHERE personal_id = ?";
    try (Connection conn = DatabaseConnection.getInstance().getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, miembro.getPersonal_id()); // ID del miembro a desasociar
        pstmt.executeUpdate();
        
        miembros.remove(miembro); // Remover de la lista en memoria
        System.out.println("Miembro " + miembro.getNombre() + " removido de la cuadrilla " + this.nombre);
    } catch (SQLException e) {
        System.out.println("Error al remover miembro: " + e.getMessage());
    }
}

// Listar miembros asociados a esta cuadrilla desde la base de datos
public List<Personal> listarMiembros() {
    List<Personal> miembrosDesdeBD = new ArrayList<>();
    String sql = "SELECT * FROM personal WHERE cuadrilla_id = ?";
    try (Connection conn = DatabaseConnection.getInstance().getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, this.cuadrilla_id); // Filtrar por la cuadrilla actual
        ResultSet rs = pstmt.executeQuery();
        
        while (rs.next()) {
            Personal miembro = new Personal(
                rs.getInt("personal_id"),
                rs.getString("nombre"),
                rs.getInt("cuadrilla_id")
            );
            miembrosDesdeBD.add(miembro);
        }
    } catch (SQLException e) {
        System.out.println("Error al listar miembros: " + e.getMessage());
    }
    
    miembros = miembrosDesdeBD; // Sincronizar la lista en memoria con los datos de la base
    return miembrosDesdeBD;
}


    // Getters y setters
    public int getCuadrilla_id() {
        return cuadrilla_id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public int getJefeCuadrilla_id() {
        return jefeCuadrilla_id;
    }

    public void setCuadrilla_id(int cuadrilla_id) {
        this.cuadrilla_id = cuadrilla_id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setJefeCuadrilla_id(int jefeCuadrilla_id) {
        this.jefeCuadrilla_id = jefeCuadrilla_id;
    }
}

