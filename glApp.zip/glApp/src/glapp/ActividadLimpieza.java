/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package glapp;

/**
 *
 * @author edw09
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import conexion.DatabaseConnection;
import javax.swing.JOptionPane;

public class ActividadLimpieza {
    private int ActividadLimpieza_id;
    private String descripcion;
    private Date fecha;
    private int colonia_id; // ID del lugar
    private int cuadrillaId; // ID de la cuadrilla
    private byte[] imagen; // Imagen como BLOB

    // Constructor
    public ActividadLimpieza(int ActividadLimpieza_id, String descripcion, Date fecha, int colonia_id, int cuadrillaId, byte[] imagen) {
        this.ActividadLimpieza_id = ActividadLimpieza_id;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.colonia_id = colonia_id;
        this.cuadrillaId = cuadrillaId;
        this.imagen = imagen;
    }

    // Métodos CRUD de ActividadLimpieza en la base de datos
    public void guardar() {
        String sql = "INSERT INTO actividadlimpieza (ActividadLimpieza_id, descripcion, fecha, colonia_id, cuadrilla_id, imagen) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, this.ActividadLimpieza_id);
            pstmt.setString(2, this.descripcion);
            pstmt.setDate(3, new java.sql.Date(this.fecha.getTime()));
            pstmt.setInt(4, this.colonia_id);
            pstmt.setInt(5, this.cuadrillaId);
            pstmt.setBytes(6, this.imagen);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Actividad de limpieza guardada exitosamente.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al guardar la actividad de limpieza: " + e.getMessage());
        }
    }

    public static ActividadLimpieza obtenerPorId(int ActividadLimpieza_id) {
        String sql = "SELECT * FROM actividadlimpieza WHERE ActividadLimpieza_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ActividadLimpieza_id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new ActividadLimpieza(
                        rs.getInt("ActividadLimpieza_id"),
                        rs.getString("descripcion"),
                        rs.getDate("fecha"),
                        rs.getInt("colonia_id"),
                        rs.getInt("cuadrilla_id"),
                        rs.getBytes("imagen")
                );
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al obtener la actividad de limpieza: " + e.getMessage());
        }
        return null;
    }

    public void actualizar(int id, String descripcion, Date fecha, int coloniaId, int cuadrillaId, byte[] imagen) {
    String sql = "UPDATE actividadlimpieza SET descripcion = ?, fecha = ?, colonia_id = ?, cuadrilla_id = ?, imagen = ? WHERE ActividadLimpieza_id = ?";
    try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

        // Asignar los valores a los parámetros
        pstmt.setString(1, descripcion);
        pstmt.setDate(2, new java.sql.Date(fecha.getTime())); // Convertir Date a java.sql.Date
        pstmt.setInt(3, coloniaId);
        pstmt.setInt(4, cuadrillaId);
        pstmt.setBytes(5, imagen); // Imagen como byte[]
        pstmt.setInt(6, id);

        // Ejecutar la actualización
        pstmt.executeUpdate();
    } catch (SQLException e) {
        throw new RuntimeException("Error al actualizar la actividad: " + e.getMessage(), e);
    }
}


    public void eliminar() {
        String sql = "DELETE FROM actividadlimpieza WHERE ActividadLimpieza_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, this.ActividadLimpieza_id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Actividad de limpieza eliminada exitosamente.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al eliminar la actividad de limpieza: " + e.getMessage());
        }
    }

    // Getters y setters
    public int getActividadLimpieza_id() {
        return ActividadLimpieza_id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public int getColonia_id() {
        return colonia_id;
    }

    public int getCuadrillaId() {
        return cuadrillaId;
    }

    public void setActividadLimpieza_id(int ActividadLimpieza_id) {
        this.ActividadLimpieza_id = ActividadLimpieza_id;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setColonia_id(int lugarId) {
        this.colonia_id = lugarId;
    }

    public void setCuadrillaId(int cuadrillaId) {
        this.cuadrillaId = cuadrillaId;
    }
    
    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }
}




